package studio.strata.wallpaper;
import android.service.wallpaper.WallpaperService;
import android.graphics.Canvas;
import android.hardware.*;
import android.os.*;
import android.view.SurfaceHolder;

public final class LiveWallpaper extends WallpaperService {
    public Engine onCreateEngine(){return new LiveEngine();}
    final class LiveEngine extends Engine implements SensorEventListener {
        final Handler h=new Handler(Looper.getMainLooper()); final Scene.Renderer renderer=new Scene.Renderer(LiveWallpaper.this);Scene scene;SensorManager manager;Sensor gravity;boolean visible=false,ready=false;float gx=0,gy=0;long start;
        final Runnable frame=()->draw();
        @Override public void onCreate(SurfaceHolder holder){super.onCreate(holder);manager=(SensorManager)getSystemService(SENSOR_SERVICE);gravity=manager.getDefaultSensor(Sensor.TYPE_GRAVITY);if(gravity==null)gravity=manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);scene=Scene.read(LiveWallpaper.this);start=SystemClock.uptimeMillis();}
        @Override public void onVisibilityChanged(boolean v){visible=v;h.removeCallbacks(frame);manager.unregisterListener(this);if(v){scene=Scene.read(LiveWallpaper.this);if(gravity!=null&&scene.layers.stream().anyMatch(l->l.visible&&l.parallaxOn))manager.registerListener(this,gravity,SensorManager.SENSOR_DELAY_GAME);draw();}}
        @Override public void onSurfaceCreated(SurfaceHolder holder){super.onSurfaceCreated(holder);ready=true;draw();}
        @Override public void onSurfaceChanged(SurfaceHolder holder,int format,int w,int ht){super.onSurfaceChanged(holder,format,w,ht);ready=true;draw();}
        @Override public void onSurfaceDestroyed(SurfaceHolder holder){ready=false;h.removeCallbacks(frame);manager.unregisterListener(this);super.onSurfaceDestroyed(holder);}
        @Override public void onDestroy(){visible=false;ready=false;h.removeCallbacks(frame);manager.unregisterListener(this);super.onDestroy();}
        public void onSensorChanged(SensorEvent e){gx=.88f*gx+.12f*Math.max(-1,Math.min(1,-e.values[0]/5));gy=.88f*gy+.12f*Math.max(-1,Math.min(1,(e.values[1]-3)/5));}public void onAccuracyChanged(Sensor s,int a){}
        void draw(){h.removeCallbacks(frame);if(!ready||scene==null)return;Canvas c=null;SurfaceHolder holder=getSurfaceHolder();try{c=holder.lockCanvas();if(c!=null)renderer.draw(c,scene,(int)((SystemClock.uptimeMillis()-start)%scene.duration),gx,gy,"");}catch(RuntimeException ignored){}finally{if(c!=null)try{holder.unlockCanvasAndPost(c);}catch(RuntimeException ignored){}}if(visible){boolean dynamic=scene.layers.stream().anyMatch(l->l.visible&&(l.parallaxOn||(l.animate&&(l.kind.equals("particles")||!l.keys.isEmpty()||!l.motion.equals("None")))));h.postDelayed(frame,dynamic?33:1000);}}
    }
}
